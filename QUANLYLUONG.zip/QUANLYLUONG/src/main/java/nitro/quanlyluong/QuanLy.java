package nitro.quanlyluong;

/**
 *
 * @author Admin
 */
interface QuanLy {
    abstract double tinhHoaHong();
}
